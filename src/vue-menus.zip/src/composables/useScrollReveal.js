import { ref, onMounted, onUnmounted } from 'vue'

export function useScrollReveal(options = {}) {
  const elementRef = ref(null)
  const isVisible = ref(false)

  let observer

  const defaultOptions = {
    threshold: 0.1,
    rootMargin: '0px',
    once: true,
  }

  const combinedOptions = { ...defaultOptions, ...options }

  const callback = (entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        isVisible.value = true
        if (combinedOptions.once && observer) observer.unobserve(entry.target)
      }
    })
  }

  onMounted(() => {
    observer = new IntersectionObserver(callback, combinedOptions)
    if (elementRef.value) observer.observe(elementRef.value)
  })

  onUnmounted(() => {
    if (observer && elementRef.value) observer.unobserve(elementRef.value)
  })

  return { elementRef, isVisible }
}
