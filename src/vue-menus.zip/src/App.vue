<template>
  <div class="p-8">
    <button
      @click="showModal = true"
      class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition"
    >
      Open Modal
    </button>

    <ReusableModal
      v-model="showModal"
      title="My Awesome Modal"
      width="max-w-2xl"
      :transition-duration="0.5"
      @close="handleClose"
      @confirm="handleConfirm"
    >
      <p class="mb-2">This is the content of my reusable modal!</p>
      <ul class="list-disc list-inside space-y-1">
        <li>Item 1</li>
        <li>Item 2</li>
      </ul>
    </ReusableModal>
    
  </div>
</template>

<script setup>
import { ref } from 'vue';
import ReusableModal from '@/components/GsapModal.vue';

const showModal = ref(false);

const handleClose = () => {
  console.log('Modal closed');
};

const handleConfirm = () => {
  console.log('Modal confirmed!');
  showModal.value = false;
};
</script>

<style scoped>
/* Optional: add additional styling here */
</style>
