<script setup>
import { ref, onMounted, onBeforeUnmount, watch } from 'vue';
import gsap from 'gsap';

// Props
const props = defineProps({
  modelValue: Boolean,
  title: String,
  width: {
    type: String,
    default: 'max-w-md',
  },
  transitionDuration: {
    type: Number,
    default: 0.3, // seconds
  },
});

// Emits
const emit = defineEmits(['update:modelValue', 'close', 'confirm']);

// Refs
const modal = ref(null);
const isOpen = ref(props.modelValue);

// Watch for external modelValue changes
watch(
  () => props.modelValue,
  (newValue) => {
    isOpen.value = newValue;
    animateModal(newValue);
  }
);

// Animate modal open/close
const animateModal = (open, onCompleteCallback) => {
  const duration = props.transitionDuration;
  const ease = 'power3.out';

  if (open && modal.value) {
    gsap.fromTo(
      modal.value,
      { opacity: 0, y: -20 },
      { opacity: 1, y: 0, duration, ease }
    );
  } else if (modal.value) {
    gsap.to(modal.value, {
      opacity: 0,
      y: -20,
      duration,
      ease,
      onComplete: onCompleteCallback,
    });
  }
};

// Close modal handler
const closeModal = () => {
  isOpen.value = false;
  animateModal(false, () => {
    emit('update:modelValue', false);
    emit('close');
  });
};

// Escape key close
const handleKeyDown = (e) => {
  if (e.key === 'Escape') {
    closeModal();
  }
};

// Lifecycle
onMounted(() => {
  window.addEventListener('keydown', handleKeyDown);
  if (isOpen.value && modal.value) {
    gsap.fromTo(
      modal.value,
      { opacity: 0, y: -20 },
      { opacity: 1, y: 0, duration: props.transitionDuration, ease: 'power3.out' }
    );
  }
});

onBeforeUnmount(() => {
  window.removeEventListener('keydown', handleKeyDown);
});
</script>

<template>
  <Transition name="fade">
    <div
      v-if="isOpen"
      class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50"
      @click="closeModal"
    >
      <div
        ref="modal"
        :class="['bg-white rounded-lg shadow-xl overflow-hidden', width]"
        @click.stop
      >
        <!-- Header -->
        <div class="px-6 py-4 border-b">
          <h3 class="text-xl font-semibold">{{ title }}</h3>
        </div>

        <!-- Body -->
        <div class="p-6">
          <slot></slot>
        </div>

        <!-- Footer -->
        <div class="px-6 py-3 bg-gray-50 border-t flex justify-end gap-2">
          <button
            class="px-4 py-2 bg-gray-300 hover:bg-gray-400 text-gray-800 rounded-md focus:outline-none focus:ring focus:ring-gray-200 active:bg-gray-500"
            @click="closeModal"
          >
            Cancel
          </button>
          <button
            class="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-md focus:outline-none focus:ring focus:ring-blue-200 active:bg-blue-700"
            @click="$emit('confirm')"
          >
            Confirm
          </button>
        </div>
      </div>
    </div>
  </Transition>
</template>

<style scoped>
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s ease;
}
.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>
