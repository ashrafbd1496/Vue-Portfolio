<template>
  <div ref="sectionRef" class="h-screen w-full overflow-hidden relative">
    <div
      ref="horizontalRef"
      class="flex h-full absolute"
      :style="{ width: `${sections.length * 100}%` }"
    >
      <div
        v-for="(section, index) in sections"
        :key="index"
        class="w-screen h-full flex items-center justify-center text-4xl font-bold"
        :class="section.bgClass"
      >
        {{ section.title }}
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from "vue";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

// Register ScrollTrigger plugin
gsap.registerPlugin(ScrollTrigger);

// Define sections with background classes
const sections = [
  { title: "Section 1", bgClass: "bg-blue-100" },
  { title: "Section 2", bgClass: "bg-green-100" },
  { title: "Section 3", bgClass: "bg-purple-100" },
];

// References for GSAP animation
const sectionRef = ref(null);
const horizontalRef = ref(null);

// Animation timeline
let scrollTween = null;

onMounted(() => {
  // Ensure refs are populated
  if (sectionRef.value && horizontalRef.value) {
    // Create horizontal scroll animation
    scrollTween = gsap.to(horizontalRef.value, {
      x: () =>
        -(
          horizontalRef.value.scrollWidth - document.documentElement.clientWidth
        ),
      ease: "none",
      scrollTrigger: {
        trigger: sectionRef.value,
        start: "top top",
        end: () =>
          `+=${
            horizontalRef.value.scrollWidth -
            document.documentElement.clientWidth
          }`,
        scrub: 1,
        pin: true,
        anticipatePin: 1,
      },
    });
  }
});

// Cleanup animation on component unmount
onUnmounted(() => {
  if (scrollTween) {
    scrollTween.kill();
  }
  ScrollTrigger.getAll().forEach((trigger) => trigger.kill());
});
</script>
