<template>
  <nav class="nav-container" :class="{ 'mobile-open': isMobileMenuOpen }">
    <div class="nav-content">
      <div class="logo" ref="logo">
        <router-link to="/">
          <img src="../assets/logo.png" alt="Logo" />
        </router-link>
      </div>

      <div class="hamburger" ref="hamburger" @click="toggleMobileMenu">
        <div class="bar" :class="{ open: isMobileMenuOpen }"></div>
        <div class="bar" :class="{ open: isMobileMenuOpen }"></div>
        <div class="bar" :class="{ open: isMobileMenuOpen }"></div>
      </div>

      <div class="nav-links">
        <ul>
          <li
            v-for="(link, index) in navLinks"
            :key="index"
            @mouseenter="handleHoverEnter($event)"
            @mouseleave="handleHoverLeave($event)"
          >
            <router-link :to="link.path">{{ link.name }}</router-link>
          </li>
        </ul>
      </div>
    </div>

    <div class="mobile-menu" ref="mobileMenu">
      <ul>
        <li
          v-for="(link, index) in navLinks"
          :key="index"
          @mouseenter="handleHoverEnter($event)"
          @mouseleave="handleHoverLeave($event)"
        >
          <router-link :to="link.path" @click="closeMobileMenu">{{
            link.name
          }}</router-link>
        </li>
      </ul>
    </div>
  </nav>
</template>

<script>
import { ref, onMounted, onUnmounted } from "vue";
import gsap from "gsap";

export default {
  name: "NavigationMenu",

  setup() {
    const navLinks = [
      { name: "Home", path: "/" },
      { name: "About", path: "/about" },
      { name: "Services", path: "/services" },
      { name: "Portfolio", path: "/portfolio" },
      { name: "Contact", path: "/contact" },
    ];

    const isMobileMenuOpen = ref(false);
    const logo = ref(null);
    const hamburger = ref(null);
    const mobileMenu = ref(null);

    const navItem = ref(null); // will be set to NodeList
    const mobileItem = ref(null); // will be set to NodeList

    const timeline = gsap.timeline({ paused: true });
    let windowWidth = null;

    const toggleMobileMenu = () => {
      isMobileMenuOpen.value = !isMobileMenuOpen.value;
      isMobileMenuOpen.value ? timeline.play() : timeline.reverse();
    };

    const closeMobileMenu = () => {
      if (isMobileMenuOpen.value) {
        isMobileMenuOpen.value = false;
        timeline.reverse();
      }
    };

    const handleResize = () => {
      windowWidth = window.innerWidth;

      if (windowWidth > 768 && isMobileMenuOpen.value) {
        closeMobileMenu();
      }

      initAnimations();
    };

    const initAnimations = () => {
      if (!mobileMenu.value || !mobileItem.value) return;

      timeline.clear();

      gsap.set(navItem.value, {
        y: 0,
        opacity: 1,
      });

      gsap.set(mobileMenu.value, {
        y: -20,
        opacity: 0,
        display: "none",
      });

      gsap.set(mobileItem.value, {
        y: 20,
        opacity: 0,
      });

      timeline
        .to(mobileMenu.value, {
          display: "block",
          duration: 0,
        })
        .to(mobileMenu.value, {
          y: 0,
          opacity: 1,
          duration: 0.4,
          ease: "power3.out",
        })
        .to(
          mobileItem.value,
          {
            y: 0,
            opacity: 1,
            duration: 0.4,
            stagger: 0.1,
            ease: "power3.out",
          },
          "-=0.2"
        );
    };

    const animateLogo = () => {
      gsap.from(logo.value, {
        opacity: 0,
        x: -20,
        duration: 1,
        ease: "power3.out",
      });
    };

    const animateNavLinks = () => {
      gsap.from(navItem.value, {
        opacity: 0,
        y: -20,
        duration: 0.6,
        stagger: 0.1,
        ease: "power3.out",
      });
    };

    onMounted(() => {
      windowWidth = window.innerWidth;
      window.addEventListener("resize", handleResize);

      // Get nav and mobile items
      navItem.value = document.querySelectorAll(".nav-links ul li");
      mobileItem.value = document.querySelectorAll(".mobile-menu ul li");

      initAnimations();
      animateLogo();
      animateNavLinks();
    });

    onUnmounted(() => {
      window.removeEventListener("resize", handleResize);
    });

    const handleHoverEnter = (event) => {
      const link =
        event.currentTarget.querySelector("a") || event.currentTarget;
      gsap.to(link, {
        y: -5,
        color: "#007bff",
        duration: 0.3,
        ease: "power2.out",
      });
    };

    const handleHoverLeave = (event) => {
      const link =
        event.currentTarget.querySelector("a") || event.currentTarget;
      gsap.to(link, {
        y: 0,
        color: "#333",
        duration: 0.3,
        ease: "power2.out",
      });
    };

    return {
      navLinks,
      isMobileMenuOpen,
      toggleMobileMenu,
      closeMobileMenu,
      logo,
      hamburger,
      mobileMenu,
      handleHoverEnter,
      handleHoverLeave,
    };
  },
};
</script>

<style scoped>
.nav-container {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  background-color: #ffffff;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  z-index: 1000;
}

.nav-content {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1rem 2rem;
  max-width: 1200px;
  margin: 0 auto;
}

.logo {
  z-index: 1001;
}

.logo img {
  max-height: 40px;
}

.nav-links {
  display: flex;
}

.nav-links ul {
  display: flex;
  list-style: none;
  margin: 0;
  padding: 0;
}

.nav-links li {
  margin-left: 2rem;
}

.nav-links a {
  text-decoration: none;
  color: #333;
  font-weight: 500;
  padding: 0.5rem 0;
  position: relative;
  transition: color 0.3s ease;
}

.nav-links a:hover {
  color: #007bff;
}

.nav-links a::after {
  content: "";
  position: absolute;
  bottom: 0;
  left: 0;
  width: 0;
  height: 2px;
  background-color: #007bff;
  transition: width 0.3s ease;
}

.nav-links a:hover::after {
  width: 100%;
}

.hamburger {
  display: none;
  cursor: pointer;
  z-index: 1001;
}

.bar {
  width: 30px;
  height: 3px;
  background-color: #333;
  margin: 6px 0;
  transition: 0.4s;
}

.bar.open:nth-child(1) {
  transform: rotate(-45deg) translate(-5px, 6px);
}

.bar.open:nth-child(2) {
  opacity: 0;
}

.bar.open:nth-child(3) {
  transform: rotate(45deg) translate(-5px, -6px);
}

.mobile-menu {
  display: none;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100vh;
  background-color: #ffffff;
  z-index: 1000;
  padding-top: 5rem;
}

.mobile-menu ul {
  list-style: none;
  padding: 0;
  margin: 0;
}

.mobile-menu li {
  padding: 1rem 2rem;
  text-align: center;
}

.mobile-menu a {
  text-decoration: none;
  color: #333;
  font-size: 1.5rem;
  font-weight: 500;
  transition: color 0.3s ease;
}

.mobile-menu a:hover {
  color: #007bff;
}
.nav-links a:hover,
.mobile-menu a:hover {
  color: inherit; /* Remove default hover color */
}

/* Responsive styles */
@media screen and (max-width: 768px) {
  .nav-links {
    display: none;
  }

  .hamburger {
    display: block;
  }
}
</style>
