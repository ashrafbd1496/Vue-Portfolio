<script setup>
import { onMounted, ref } from 'vue'
import { gsap } from 'gsap'

// References to DOM elements
const heroTitle = ref(null)
const heroSubtitle = ref(null)
const heroImage = ref(null)
const ctaButton = ref(null)
const heroSection = ref(null)

onMounted(() => {
  // Create a GSAP timeline for sequential animations
  const tl = gsap.timeline({ defaults: { ease: 'power1.out' } })

  // Animate hero section background
  tl.fromTo(
    heroSection.value, 
    { backgroundColor: 'rgba(255,255,255,0)' }, 
    { backgroundColor: 'rgba(255,255,255,1)', duration: 1 }
  )

  // Animate title with staggered letters
  tl.fromTo(
    heroTitle.value,
    { opacity: 0, y: 50 },
    { opacity: 1, y: 0, duration: 1 },
    '-=0.5'
  )

  // Animate subtitle
  tl.fromTo(
    heroSubtitle.value,
    { opacity: 0, y: 50 },
    { opacity: 1, y: 0, duration: 1 },
    '-=0.7'
  )

  // Animate hero image
  tl.fromTo(
    heroImage.value,
    { opacity: 0, scale: 0.2 },
    { opacity: 1, scale: 1, duration: 1 },
    '-=0.6'
  )

  // Animate CTA button
  tl.fromTo(
    ctaButton.value,
    { opacity: 0, y: 50 },
    { opacity: 1, y: 0, duration: 1 },
    '-=0.5'
  )
})
</script>

<template>
  <div ref="heroSection" class="min-h-screen flex items-center justify-center p-6 bg-white">
    <div class="max-w-6xl mx-auto grid md:grid-cols-2 gap-8 items-center">
      <div class="space-y-6">
        <h1 
          ref="heroTitle" 
          class="text-5xl font-bold text-gray-900 opacity-0"
        >
          Welcome to Your Digital Journey
        </h1>
        
        <p 
          ref="heroSubtitle" 
          class="text-xl text-gray-600 opacity-0"
        >
          Discover innovative solutions that transform your business and drive growth.
        </p>
        
        <button 
          ref="ctaButton"
          class="bg-cyan-600 text-white px-8 py-3 rounded-lg hover:bg-cyan-700 transition opacity-0"
        >
          Get Started
        </button>
      </div>
      
      <div ref="heroImage" class="opacity-0">
        <img 
          src="@/assets/timeline.jpg" 
          alt="Hero Image" 
          class="w-full h-auto rounded-lg shadow-xl"
        />
      </div>
    </div>
  </div>
</template>

<style scoped>
/* Additional styling can be added here */
</style>