<template>
  <div
    ref="elementRef"
    :class="['reveal', animation, { 'visible': isVisible }]"
  >
    <slot />
  </div>
</template>

<script setup>
import { defineProps } from 'vue'
import { useScrollReveal } from '../composables/useScrollReveal'

const props = defineProps({
  animation: {
    type: String,
    default: 'fade', // 'fade', 'slide', 'zoom'
  }
})

const { elementRef, isVisible } = useScrollReveal()
</script>

<style scoped>
.reveal {
  opacity: 0;
  transition: all 0.6s ease-out;
}

/* === Fade === */
.fade {
  transform: translateY(20px);
}
.fade.visible {
  opacity: 1;
  transform: translateY(0);
}

/* === Slide (from left) === */
.slide {
  transform: translateX(-40px);
}
.slide.visible {
  opacity: 1;
  transform: translateX(0);
}

/* === Zoom === */
.zoom {
  transform: scale(0.8);
}
.zoom.visible {
  opacity: 1;
  transform: scale(1);
}
.box {
  height: 200px;
  background: #f28b82;
  margin: 2rem;
  padding: 2rem;
  border-radius: 10px;
  text-align: center;
  font-size: 1.5rem;
}
</style>