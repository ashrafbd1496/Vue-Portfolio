<script setup>
import { ref, onMounted, onUnmounted, watch, nextTick } from "vue";
import { gsap } from "gsap";

// Destructured props with validation and defaults
const { animationType, delay, duration, threshold } = defineProps({
  animationType: {
    type: String,
    default: "fade",
    validator: (value) => ["fade", "slide", "scale"].includes(value),
  },
  delay: {
    type: Number,
    default: 0,
  },
  duration: {
    type: Number,
    default: 1,
  },
  threshold: {
    type: Number,
    default: 0.1,
  },
});

// Refs
const elementRef = ref(null);
const isInView = ref(false);
const hasAnimated = ref(false);

let observer = null;

// Create Intersection Observer
const createObserver = () => {
  const options = {
    root: null,
    rootMargin: "0px",
    threshold: threshold,
  };

  observer = new IntersectionObserver(([entry]) => {
    if (entry.isIntersecting && !hasAnimated.value) {
      isInView.value = true;
      hasAnimated.value = true;
    }
  }, options);

  return observer;
};

// Animation logic
const animateElement = () => {
  if (!elementRef.value) return;

  // Set initial state
  gsap.set(elementRef.value, {
    opacity: 0,
    y: animationType === "slide" ? 50 : 0,
    scale: animationType === "scale" ? 0.9 : 1,
  });

  // Animate based on type
  const config = {
    opacity: 1,
    duration,
    delay,
    ease: "power2.out",
  };

  if (animationType === "slide") {
    config.y = 0;
  } else if (animationType === "scale") {
    config.scale = 1;
    config.ease = "back.out(1.7)";
  }

  gsap.to(elementRef.value, config);
};

// Watch and lifecycle
watch(isInView, (inView) => {
  if (inView) {
    animateElement();
    observer && observer.disconnect();
  }
});

onMounted(async () => {
  createObserver();
  await nextTick();

  if (elementRef.value) {
    observer.observe(elementRef.value);
  }
});

onUnmounted(() => {
  observer && observer.disconnect();
});
</script>

<template>
  <div ref="elementRef" class="gsap-reveal">
    <slot />
  </div>
</template>

<style scoped>
.gsap-reveal {
  opacity: 0;
  will-change: opacity, transform;
}
</style>
