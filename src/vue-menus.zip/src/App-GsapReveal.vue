<template>
  <div class="app-container">
    <div class="long-content">
      <!-- Placeholder content to enable scrolling -->
      <div v-for="n in 5" :key="n" class="placeholder-section">Scroll Down</div>
    </div>

    <GSAPReveal animation-type="slide" :delay="0.2" :duration="1.5">
      <div class="content-box">
        <h1>Scroll to Reveal Slide</h1>
        <p>This element will slide in when it comes into view!</p>
      </div>
    </GSAPReveal>

    <div class="long-content">
      <div v-for="n in 5" :key="n" class="placeholder-section">
        Keep Scrolling
      </div>
    </div>

    <GSAPReveal animation-type="scale" :delay="0.4">
      <div class="content-box">
        <h2>Scale Reveal</h2>
        <p>Another animation type with custom delay.</p>
      </div>
    </GSAPReveal>

    <div class="long-content">
      <div v-for="n in 5" :key="n" class="placeholder-section">
        Almost There
      </div>
    </div>

    <GSAPReveal animation-type="fade" :delay="0.3" :threshold="0.2">
      <div class="content-box">
        <h2>Fade Reveal</h2>
        <p>Subtle fade animation with different threshold.</p>
      </div>
    </GSAPReveal>
  </div>
</template>

<script setup>
// Importing the Navbar component Asynchronously
import { defineAsyncComponent } from "vue";
//const Navbar = defineAsyncComponent(() => import('@/components/Nav.vue'));
//const RevealSection = defineAsyncComponent(() => import('@/components/RevealSection.vue'));
//const HorizontalScroll = defineAsyncComponent(() => import('@/components/HorizontalScroll.vue'));
import GSAPReveal from "@/components/GsapReveal.vue";
//const Timeline = defineAsyncComponent(() => import('@/components/Timeline.vue'));
</script>
<style scoped>
.app-container {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.content-box {
  background-color: #f4f4f4;
  padding: 30px;
  margin-bottom: 20px;
  border-radius: 8px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.long-content {
  height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background-color: #f0f0f0;
  margin-bottom: 20px;
}

.placeholder-section {
  height: 200px;
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #e0e0e0;
  margin: 10px 0;
  font-size: 24px;
  color: #666;
}
</style>
